# datamining
Data Mining Semester Final Project 

#Step 1:

 Open the ipynb file in the jupyter Notebook
 
 #Step 2:
 
 Upload the CSV Dataset file named "A-ZHandwritten Data" into the jupyter notebook.
 
 #Step 3:
 
 Run each cell in sequential order till the this heading - "Doing Some Predictions on Test Data".
 
 #step 4:
 
 After prediction on test data. We will try to run the project on externally provided image inputs. 
 These will be available in External Inputs Folder in git. 
 Select the image you plan on to predict. 
 Copy the path location and replace it in this line "img = cv2.imread(r'C:\Users\Anudeep\Desktop\E.png')".
 
 #step 5:
 
 Run the remaining all cells. You can see the prediction. 
 
 #step 6:
 
 Use Esc button to stop.
 
 #step 7:
 
 Repeat same from step 4 to step 6 for other external inputs.
 
 
 
 
